# Task 1: Basic Mathematical Operations

try:
    # 1. Take two numbers as input from the user
    num1 = float(input("Enter the first number: "))
    num2 = float(input("Enter the second number: "))

    # 2. Perform operations and 3. Display the results
    print("\n--- Results ---")

    # Addition
    print(f"Addition: {num1} + {num2} = {num1 + num2}")

    # Subtraction
    print(f"Subtraction: {num1} - {num2} = {num1 - num2}")

    # Multiplication
    print(f"Multiplication: {num1} * {num2} = {num1 * num2}")

    # Division (with a check for division by zero)
    if num2 != 0:
        print(f"Division: {num1} / {num2} = {num1 / num2}")
    else:
        print("Division: Cannot divide by zero!")

except ValueError:
    print("Invalid input! Please enter valid numbers.")