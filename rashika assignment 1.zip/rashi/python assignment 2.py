# Task 2: Personalized Greeting

# 1. Take user's first name and last name as input
first_name = input("Enter your first name: ")
last_name = input("Enter your last name: ")

# 2. Concatenate the first name and last name into a full name
# The + " " + adds a space between the two names
full_name = first_name + " " + last_name

# 3. Print a personalized greeting message
print(f"\nHello, {full_name}! Welcome to the Python assignment.")